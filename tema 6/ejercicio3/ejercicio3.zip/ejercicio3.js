window.addEventListener("load", inicio);

function inicio(){

    //ul
    var ul = document.createElement('ul');

    //li    
    var li1 = document.getElementsByTagName("li").type="square";
    var coche1 = document.createTextNode("Ford");
    li1.appendChild(coche1);
    
    
    var li2 = document.getElementsByTagName("li").type="square";
    var coche2 = document.createTextNode("BMV");
    //li2.appendChild(coche2);

    //ul.appendChild(li1);
    //ul.appendChild(li2);
}